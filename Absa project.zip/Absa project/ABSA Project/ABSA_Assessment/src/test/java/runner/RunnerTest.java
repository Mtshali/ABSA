package runner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;

import accelerators.Base;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import utility.Utils;

@RunWith(Cucumber.class)
@CucumberOptions(
		features ="AbsaAutomation/features",
		glue= "seleniumgluecode",
		//tags= {"~@Admin","@NotWorking","~@Working"},
		//plugin = {"com.cucumber.listener.ExtentReport:ProjectData/target/cucumber-reports/report.html"}, 
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"}, 
		monochrome = true)
//Please check the report in ProjectData>target>Cucumber-reports

public class RunnerTest {
	public static String sReportName="";
	@BeforeClass
	public static void setUpData() {
		try {

		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	@AfterClass
	public static void teardown() {

		Reporter.setSystemInfo("Browser", Utils.getProperty("browserName"));
		Reporter.setSystemInfo("Browser Version", Base.sBrowserVersion);
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Reporter.setSystemInfo("Machine", 	"Windows 10" + " 64 Bit");
		Reporter.setSystemInfo("Selenium", "3.7.1");
		Reporter.setSystemInfo("Maven", "3.7.0");
		Reporter.setSystemInfo("Java Version", "1.8");
		Reporter.setSystemInfo("Environment", Utils.getProperty("Environment"));
	}


}
