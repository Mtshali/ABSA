package accelerators;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


import utility.Log;


public class Base {
	public static WebDriver driver;
	public static boolean bResult;
	public static String sBrowserName;
	public static String sBrowserVersion;
	public static String Tdata;

	
	public static WebDriver OpenBrowser(String sBrowser) {

		try {
			if(sBrowserName.equalsIgnoreCase("Chrome")) {
				ChromeOptions options = new ChromeOptions();
				Map<String, Object> prefs = new HashMap<String, Object>();
				prefs.put("download.default_directory",  System.getProperty("user.dir")+"//Downloads");
				options.setExperimentalOption("prefs", prefs);
				options.addArguments("--use-fake-ui-for-media-stream");
				options.addArguments("--disable-user-media-security");	
				options.addArguments("--use-fake-device-for-media-stream");
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				sBrowserVersion=capabilities.getVersion();
				options.addArguments("--incognito");
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				sBrowserVersion=(String) capabilities.getCapability("version");
				System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
				driver = new ChromeDriver(options);
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				Log.info("Chrome driver initialized");
			}
			else if(sBrowserName.equalsIgnoreCase("Firefox")) {             
				System.setProperty("webdriver.gecko.driver", "Drivers/geckodriver.exe");
				driver = new FirefoxDriver();
				Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				sBrowserVersion=cap.getVersion();
				Log.info("Firefox driver initialized");
			}
			else if(sBrowserName.equalsIgnoreCase("IE")) {             
				System.setProperty("webdriver.edge.driver", "Drivers/MicrosoftWebDriver.exe");
				driver = new EdgeDriver();
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				Log.info("Edge driver initialized");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return driver;
	}
}

