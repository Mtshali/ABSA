package accelerators;

import static org.testng.Assert.fail;


import java.io.File;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import java.util.Random;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utility.Utils;
public class ActionsClass  extends Base{

	public static String browserName;
	public static boolean bResult;
	public static int Wait_Fast;
	public static Actions builder;
	public static String sTestCaseName;
	public static final String TestDataPath= System.getProperty("user.dir")+Utils.getProperty("testdatapath");

	//Function to launch an application
	public static void launchAnApplication(String url) {
		try {
			driver.get(url);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	//Function to click on an element
	public static boolean clickOnElement(By object,String elementName) {
		boolean bFlag=false;
		try {
			if(driver.findElement(object).isDisplayed()) {
				driver.findElement(object).click();
				utility.Log.info("Clicked on "+elementName);
				bFlag= true;
			}
			else {
				Assert.fail("Failed to click on "+elementName);
				utility.Log.info("Failed to click on "+elementName);
			}
		}
		catch (Exception e) {
			Assert.fail("Failed to click on "+elementName);
			utility.Log.info("Failed to click on "+elementName);

		}
		return bFlag;
	}

	//Function to click on an element
	public static boolean jsClickOnElement(By object,String elementName) {
		boolean bFlag=false;
		try {
			if(driver.findElement(object).isDisplayed()) {
				bFlag= true;
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", driver.findElement(object));
				utility.Log.info("Clicked on "+elementName);	
			}
			else {
				Assert.fail("Failed to click on "+elementName);
				utility.Log.info("Failed to click on "+elementName);
			}	
		}
		catch (Exception e) {
			Assert.fail("Failed to click on "+elementName);
			utility.Log.info("Failed to click on "+elementName);
		}
		return bFlag;
	}
	//js double click
	public static void jsDoubleClickOnElement(By object,String elementName) {
		try {
			if(driver.findElement(object).isDisplayed()) {
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				/*executor.executeScript("arguments[0].click();", driver.findElement(object));*/
				executor.executeScript("var evt = document.createEvent('MouseEvents');"+ 
						"evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);"+ 
						"arguments[0].dispatchEvent(evt);", driver.findElement(object));
				utility.Log.info("Clicked on "+elementName);
			}
			else {
				Assert.fail("Failed to click on "+elementName);
				utility.Log.info("Failed to click on "+elementName);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	//js double click
	public static String jsGetCSSofElement(By object,String elementName) {
		String sFiledColor="";
		try {
			if(driver.findElement(object).isDisplayed()) {
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				/*executor.executeScript("arguments[0].click();", driver.findElement(object));*/
				sFiledColor= executor.executeScript("arguments[0].getPropertyValue('border-bottom');", driver.findElement(object)).toString();
				sFiledColor = (String) executor.executeScript("return window.document.defaultView.getComputedStyle("+"window.document.getElementById('institution-name')).getPropertyValue('border-bottom')");

				utility.Log.info("Clicked on "+elementName);
			}
			else {
				Assert.fail("Failed to click on "+elementName);
				utility.Log.info("Failed to click on "+elementName);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return sFiledColor;
	}
	//Function to get text
	public static String getElementText(By object,String elementName) {
		String sText="";
		try {
			if(driver.findElement(object).isDisplayed()) {
				sText=driver.findElement(object).getText();
				utility.Log.info("Fetched "+elementName+" text");
			}
			else {
				Assert.fail("Failed to get text ");
				utility.Log.info("Failed to get text ");
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return sText;
	}
	//Function to click on an element
	public static void doubleClick(By object,String elementName) {
		try {
			if(driver.findElement(object).isDisplayed()) {
				WebElement mo = driver.findElement(object);
				new Actions(driver).moveToElement(mo).doubleClick().build().perform();
				utility.Log.info("Clicked on "+elementName);
			}
			else {
				Assert.fail("Failed to click on "+elementName);
				utility.Log.info("Failed to click on "+elementName);
			}
		}
		catch (Exception e) {
			Assert.fail("Failed to click on "+elementName);
		}
	}
	//Function to type in text box 
	public static void typeInTextBox(By object,String data,String elementName) {
		try {
			if(driver.findElement(object).isDisplayed()) {
				driver.findElement(object).clear();
				driver.findElement(object).sendKeys(data);
				utility.Log.info("Entered data in "+elementName+" textbox");
			}
			else {
				Assert.fail("Failed to enter data in "+elementName+" textbox");
				utility.Log.info("Failed to enter data in "+elementName+" textbox");
			}
		}
		catch (Exception e) {
			Assert.fail("Failed to enter data in "+elementName+" textbox");
		}
	}
	//Function to type in text box 
	public static void typeInTextBoxWithoutClear(By object,String data,String elementName) {
		try {
			if(driver.findElement(object).isDisplayed()) {
				driver.findElement(object).sendKeys(data);
				utility.Log.info("Entered data in "+elementName+" textbox");
			}
			else {
				Assert.fail("Failed to enter data in "+elementName+" textbox");
				utility.Log.info("Failed to enter data in "+elementName+" textbox");
			}
		}
		catch (Exception e) {
			Assert.fail("Failed to enter data in "+elementName+" textbox");
		}
	}
	//Verify element is visible on page
	public static boolean isElementVisible(By object,String elementName) {
		boolean bFlag = false;
		try {
			if(driver.findElement(object).isDisplayed()) {
				bFlag= true;
				utility.Log.info("Element "+elementName+" is visible on screen");
			}
			else {
				Assert.fail("Element "+elementName+" is not visible on screen");
				utility.Log.info("Element "+elementName+" is not visible on screen");	
			}
		} catch (Exception e) {
			Assert.fail("Element "+elementName+" is not visible on screen");
		}
		return bFlag;
	}

	//Verify element is visible on page
	public static boolean isElementNotVisible(By object,String elementName) {
		boolean bFlag = false;
		try {
			if(driver.findElement(object).isDisplayed()) {	
				bFlag= false;
				Assert.fail("Element "+elementName+" is visible on screen");
				utility.Log.info("Element "+elementName+" is visible on screen");
			}
		} catch (Exception e) {
			bFlag= true;
			utility.Log.info("Element "+elementName+" is not visible on screen");	

		}
		return bFlag;
	}
	
	public static boolean waitForElement(By Locator, long lTime){
		try{
			WebDriverWait wait = new WebDriverWait(driver, lTime);
			wait.until(ExpectedConditions.elementToBeClickable (Locator));
			Thread.sleep(4000);
			return true;
		}
		catch(Exception e){
			fail("Failed to wait for element to be visible");
			utility.Log.info("Failed to wait for element to be visible. Error=" + e.getMessage());    
			return false;
		}
	}

	//Get current date in any format
	public static String getCurrentDate(String strFormat)
	{
		try{

			DateFormat dateFormat = new SimpleDateFormat(strFormat);
			Date dateObj = new Date();
			return dateFormat.format(dateObj);
		}
		catch(Exception e){
			return null;
		}
	}
	//Convert RGB color to Hexa code
	public static String convertRGBtoHexa(String sColor) throws Throwable{
		String actualColor="";
		try{
			sColor=sColor.substring(0,sColor.indexOf(")"));
			String[] hexValue = sColor.replaceAll("[a-zA-Z]","").replace("(", "").replace(")", "").replace("0%","").replace("/", "").replace("-","").split(",");

			int hexValue1=Integer.parseInt(hexValue[0]);
			hexValue[1] = hexValue[1].trim();
			int hexValue2=Integer.parseInt(hexValue[1]);
			hexValue[2] = hexValue[2].trim();
			int hexValue3=Integer.parseInt(hexValue[2]);

			actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

		}
		catch(Exception e){
			utility.Log.info("Failed to Convert RGB color to Hexa");
			e.printStackTrace();
		}
		return actualColor;
	}
	// Select value from drop down using visible text
	public boolean selectByValue(By objElement, String sValue)
			throws Throwable {
		boolean bflag=false;
		try {
			Select s = new Select(driver.findElement(objElement));
			s.selectByValue(sValue);
			bflag = true;
			return bflag;
		} catch (Exception e) {
			return false;
		}
	}

	//Mousehover on element
	public static boolean mouseover(By objLocator)
			throws Throwable {
		boolean bflag=false;	
		try {
			builder=new Actions(driver);
			new WebDriverWait(driver, 10).ignoring(StaleElementReferenceException.class).until(ExpectedConditions.elementToBeClickable(objLocator));
			WebElement mo = driver.findElement(objLocator);
			builder.moveToElement(mo).build().perform();
			bflag = true;
			return bflag;
		} catch (Exception e) {
			return false;
		} 
	}
	//drag and drop 
	public static boolean draggable(By obj, int x, int y)
			throws Throwable {
		boolean bflag=false;
		try {
			builder=new Actions(driver);
			WebElement dragitem = driver.findElement(obj);
			builder.dragAndDropBy(dragitem, x, y).build().perform();
			bflag = true;	
			return bflag;
		} catch (Exception e) {
			return false;
		} 
	}
	//Select value by index
	public boolean selectByIndex(By objLocator, int index)
			throws Throwable {
		boolean bflag=false;	
		try {
			Select s = new Select(driver.findElement(objLocator));
			s.selectByIndex(index);
			bflag = true;
			return bflag;
		} catch (Exception e) {
			return false;
		} 
	}
	//Select by visible text
	public boolean selectByVisibleText(By objLocator, String sVisibletext) throws Throwable {
		boolean bflag=false;
		try {
			Select s = new Select(driver.findElement(objLocator));
			s.selectByVisibleText(sVisibletext);
			bflag = true;
			return bflag;
		} catch (Exception e) {
			return false;
		} 
	}
	//Switching windows
	public boolean switchingWindow(int count)
			throws Throwable {
		boolean bflag=false;
		try {
			Set<String> windows = driver.getWindowHandles();
			int windowCount = windows.size();
			String[] array = windows.toArray(new String[0]);
			for (int i = 0; i <=windowCount; i++) {
				driver.switchTo().window(array[count-1]);
				bflag = true;
			}

			return bflag;
		} catch (Exception e) {

			return false;
		} 
	}
	//Switching windows
	public static boolean switchToFrameByObj(By obj)
			throws Throwable {
		boolean bflag=false;
		try {
			driver.switchTo().frame(driver.findElement(obj));
			bflag=true;

		} catch (Exception e) {

			bflag=false;
		}
		return bflag;
	}
	//Get column count
	public int getColumncount(By objLocator) throws Exception {
		WebElement tr = driver.findElement(objLocator);
		List<WebElement> columns = tr.findElements(By.tagName("td"));
		int a = columns.size();
		return a;
	}
	//Get Row count
	public int getRowCount(By objLocator) throws Exception {
		WebElement table = driver.findElement(objLocator);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		int a = rows.size() - 1;
		return a;
	}
	//Accept an alert
	public static boolean acceptAlert() throws Exception {
		boolean bflag=false;
		String textOnAlert = null;
		Alert alert = null;
		try {
			alert = driver.switchTo().alert();
			textOnAlert=alert.getText();
			alert.accept();
			System.out.println(textOnAlert);
			bflag=true;

		} catch (NoAlertPresentException ex) {
			bflag=false;
			ex.printStackTrace();
		}
		return bflag;
	}
	//Cancel alert
	public boolean cancelAlert() throws Throwable {
		boolean bflag=false;
		String alerttext = null;
		Alert alert = null;
		try {
			alert = driver.switchTo().alert();
			alerttext=alert.getText();
			System.out.println(alerttext);
			alert.dismiss();
			return bflag;

		} catch (NoAlertPresentException ex) {
			ex.printStackTrace();
		} 
		return bflag;
	}
	//verify if checkbx clicked
	public boolean isCheckBoxChecked(By objLocator) throws Throwable {
		boolean bflag=false;
		try {
			if (driver.findElement(objLocator).isSelected()) {
				bflag=true;
			}
			return bflag;

		} catch (NoSuchElementException e) {
			bflag= false;
			return bflag;

		}

	}

	//Verify if element is enabled
	public static boolean isElementEnabled(By objLocator) throws Throwable {
		boolean bflag=false;
		try {
			if (driver.findElement(objLocator).isEnabled()) {
				bflag=true;
			}

		} catch (Exception e) {
			bflag=false;
		} 
		return bflag;
	}
	//Get value by using element attribute
	public static String getAttribute(By Obj, String sAttribute,String element) throws Throwable {
		String sValue = "";
		try {
			if (isElementVisible(Obj, element)) {
				sValue = driver.findElement(Obj).getAttribute(sAttribute);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return sValue;
	}
	//Get CSS Value of an element
	public static String getCssValue(By obj, String sCSSAttribute,String element) throws Throwable {
		String value = "";
		try{
			if (isElementVisible(obj,element)) {
				value = driver.findElement(obj).getCssValue(sCSSAttribute);
			}

		}catch(Exception e){
			e.printStackTrace();			
		}
		return value;
	}
	//Fetch element text
	public String getElementText(By locator) throws Throwable {
		String text = "";
		try{
			if (isElementVisible(locator, "Element")) {
				text = driver.findElement(locator).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}

	//Select first value from drop down
	public String selectFirstValueFromDropDown(By sDropdown,String sDropDownOptions,String dropDownName, boolean exceptionFlag) throws Throwable{
		String sValueSelected="";
		try
		{
			clickOnElement(sDropdown, dropDownName);
			waitForElement(By.xpath(sDropDownOptions), Wait_Fast);
			sValueSelected=getElementText(By.xpath(sDropDownOptions+"[1]"));
			clickOnElement(By.xpath(sDropDownOptions+"[1]"),  "First Option in "+dropDownName+" DropDown");
		}
		catch(Exception e){
			if(exceptionFlag){
				throw new Exception(e);
			}else{
				e.printStackTrace();
			}
		}
		return sValueSelected;
	}
	
	public String RandomInteger(int size) {
		Random randomGenerator = new Random();
		String s = "1";
		for (int i = 0; i < size; i++)
			s = s + "0";
		size = Integer.parseInt(s);
		String number = Integer.toString(randomGenerator.nextInt(size));
		return (number);
	}
	//Select value by clicking dropdown
	public static void selectValueByClicking(By objDropdown,By objValue) throws Throwable{
		try
		{
			clickOnElement(objDropdown, "Dropdown");
			Thread.sleep(500);
			doubleClick(objValue, " Value from drop down");
			Thread.sleep(500);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void GetScreenShot() throws Exception 
	{
		try {

			Date oDate = new Date();
			SimpleDateFormat oSDF = new SimpleDateFormat("yyyyMMddHHmmss");
			String sDate = oSDF.format(oDate);

			File fScreenshot = ((TakesScreenshot)Base.driver).getScreenshotAs(OutputType.FILE);
			String sScreenShotNameWithPath =System.getProperty("user.dir")+"\\Screenshots\\"+"Screenshot_" + sDate + ".png";
			FileUtils.copyFile(fScreenshot, new File(sScreenShotNameWithPath));
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
	}


}
