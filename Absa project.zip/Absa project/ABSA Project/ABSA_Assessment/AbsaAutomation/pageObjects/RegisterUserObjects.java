package pageObjects;


	import org.openqa.selenium.By;

	public class RegisterUserObjects {
		
		//Add button
		public static final By AddUsr_btn=By.xpath("//button[@type='add']");
		//Add User Objects
		public static final By FirstName_Txtbox=By.xpath("//input[@name='FirstName']");
		public static final By LastName_Txtbox=By.xpath("//input[@name='LastName']");
		public static final By UserName_Txtbox=By.xpath("//input[@name='UserName']");
		public static final By Password_Txtbox=By.xpath("//input[@name='Password']");
		public static final By AAA_Radiobtn=By.xpath("//*[@type='radio'][@value='15']");
		public static final By BBB_Radiobtn=By.xpath("//*[@type='radio'][@value='16']");
		public static final By Email_Txtbox=By.name("Email");
		public static final By Phone_Txtbox=By.name("Mobilephone");
		
		//Save button
		public static final By Save_btn=By.xpath("//button[@class='btn btn-success']");
		
		

	}



