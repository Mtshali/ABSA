package seleniumgluecode;

	import java.util.concurrent.TimeUnit;

	import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	//import org.openqa.selenium.WebElement;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.ui.Select;

	import accelerators.ActionsClass;
	import accelerators.Base;
	import cucumber.api.java.Before;
	import cucumber.api.java.en.And;
	import cucumber.api.java.en.Given;
	import cucumber.api.java.en.Then;
	import cucumber.api.java.en.When;
    import pageObjects.RegisterUserObjects;
import utility.ExcelUtils;
import utility.ExceptionHandle;
	import utility.Log;
	import utility.Utils;

	public class RegisterUser {
		
		//private static WebElement element=null;
		static WebDriver newdriver=Base.driver;
		static WebDriver driver1;
		public static String sNewWindow="";
		public static String uniqueName="";
		
		
		 @Before
		public void setUp() throws Exception {
			try {   
				
				DOMConfigurator.configure("log4j.xml");
				ActionsClass.sTestCaseName=this.toString();
				ActionsClass.sTestCaseName =  Utils.getTestCaseName(ActionsClass.sTestCaseName);
				Log.startTestCase(ActionsClass.sTestCaseName);

			}catch (Exception e) {
				utility.Log.info(e.getMessage());
			}
		}

		@Given("^Launch Browser$")
		public static void launchTheBrowser() 
		{
			try {
				//launch new browser
				Base.sBrowserName= Utils.getProperty("browserName");
				System.out.println("BrowserType: "+Base.sBrowserName);
				newdriver=Base.OpenBrowser(Base.sBrowserName);
				newdriver=Base.driver;
				//Base.driver=newdriver;
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		@And("^I enter first Name from properties file$")
		public static void launchTheBrowser1() 
		{
			try {
				
				 Utils.getProperty("User1FirstName");
				//System.out.println("BrowserType: "+Base.sBrowserName);
				//newdriver=Base.OpenBrowser(Base.sBrowserName);
				//newdriver=Base.driver;
				//Base.driver=newdriver;
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
			
		@Then ("^Navigate to way2Automation web page$") 
		public void NavigatetoURL() throws InterruptedException { 
			try {
				String url = Utils.getProperty("Application_URL");
				//String url = Utils.getProperty("http://www.way2automation.com/angularjs-protractor/webtables/");	
				newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
				newdriver.get(url);
				Thread.sleep(1000);
			}catch (Exception e) {

				ExceptionHandle.HandleException(e, "Failed to launch website");
			}
		}

		@Then ("^I Click on Role dropdown and select \"(.*)\" role for \"(.*)\"$")

		public void SelectRole(String sRole,String sUser) throws Throwable{
			WebElement e= newdriver.findElement(By.xpath("//select[@name='RoleId']"));
			Select s =new Select(e);
			try{
				if(sUser.equalsIgnoreCase("user1")) {
					s.selectByVisibleText(sRole);
				
				}
				else if (sUser.equalsIgnoreCase("user2")) {
					s.selectByVisibleText(sRole);
				}
			}
			catch (Exception e1) {

				ExceptionHandle.HandleException(e1, "Failed to select value from title dropdown");
			}
		}
		
		 @When ("^When I click on the Add User$") 
		 public static void ClickonElement() throws Throwable{
		 
		 try {
			 ActionsClass.clickOnElement(RegisterUserObjects.AddUsr_btn,"Add user");
		 }
			catch (Exception e) {

				ExceptionHandle.HandleException(e, "Failed to select value from title dropdown");
			}
		 }
		 @Then("^form will display contains \"(.*)\" text fields$")
		 
		 
		 public static void formdisplay(String ffields)throws Throwable{
			 try {
				 if(ActionsClass.isElementVisible(RegisterUserObjects.FirstName_Txtbox,"FirstName") && ActionsClass.isElementVisible(RegisterUserObjects.LastName_Txtbox,"LastName") 
							&& ActionsClass.isElementVisible(RegisterUserObjects.UserName_Txtbox,"UserName") && ActionsClass.isElementVisible(RegisterUserObjects.Email_Txtbox,"Email")
							&& ActionsClass.isElementVisible(RegisterUserObjects.Phone_Txtbox,"Mobile"))
				 {
					 utility.Log.info(ffields+" are displayed");
				 }
				 else {		 
					 Assert.fail(ffields+" are not displayed");
					 utility.Log.info(ffields+" are  not displayed");
					 
				 }
					
			 }
				catch (Exception e) {

					ExceptionHandle.HandleException(e,ffields+" are  not displayed");
				}
		 }

		
		 
		 @And("^I capture \"(.*)\" Textfield \"(.*)\" as \"(.*)\"$")
		 public static void fillingform(String user,String fieldName ,String fielddata) {

			 try {
				 if(fieldName.equalsIgnoreCase("FirstName"))
					       ActionsClass.typeInTextBox(By.name(fieldName), fielddata, fieldName);
				 else if(fieldName.equalsIgnoreCase("Password"))
					    ActionsClass.typeInTextBox(RegisterUserObjects.Password_Txtbox,fielddata,fieldName);
				 else if(fieldName.equalsIgnoreCase("Email"))
					    ActionsClass.typeInTextBox(RegisterUserObjects.Email_Txtbox,fielddata,fieldName);
				 else if(fieldName.equalsIgnoreCase("Cellnumber"))
					 ActionsClass.typeInTextBox(RegisterUserObjects.Phone_Txtbox,fielddata,fieldName);
						 
					 }
				catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to select value from title dropdown");
				}
			 
			 
		 }

		 @Then("^I click on the \"(.*)\" Button$")
		 
		 public static void ClickOnBtn(String btnName) throws Throwable{
		        try{
		            if(btnName.equalsIgnoreCase("Add User")) {
		                ActionsClass.clickOnElement(RegisterUserObjects.AddUsr_btn,"Add Users");
		                Thread.sleep(2000);
		            }else if(btnName.equalsIgnoreCase("Save")) {
		                ActionsClass.clickOnElement(RegisterUserObjects.Save_btn,"Save");
		                Thread.sleep(1000);
		            }
		        }
			   catch (Exception e) {

						ExceptionHandle.HandleException(e, "Failed to click on"+btnName);
			   }
		 }
		 
		 @And("^I select \"(.*)\" radio button for \"(.*)\"$")
		 public static void selectingBtn(String btnName,String UserName) {
		   try {
			 if(UserName.equalsIgnoreCase("User1")) {
				 ActionsClass.clickOnElement(RegisterUserObjects.AAA_Radiobtn,"AAA_Radiobtn");
				 Thread.sleep(2000);
			 }else if(UserName.equalsIgnoreCase("User2")) {
				 ActionsClass.clickOnElement(RegisterUserObjects.BBB_Radiobtn,"BBB_Radiobtn");
				 Thread.sleep(2000);
			 }
			 }
	      catch (Exception e) {
	              ExceptionHandle.HandleException(e, "Failed to click on"+btnName);
				   }	 
		 }
			@Then("^I enter unique UserName$")  
			public static void UniqueuserName()throws Throwable {
			
			try {
				uniqueName="UserName"+ActionsClass.getCurrentDate("ddmmss");
				ActionsClass.typeInTextBox(RegisterUserObjects.UserName_Txtbox,uniqueName, "UserName");
				Thread.sleep(1000);
				}
			    catch (Exception e){
			    	ExceptionHandle.HandleException(e, "Unable to enter unique name");	
			    }
			}
			
			@And("^I am in User List Table$")
			 public static boolean validatetable() {
				boolean bflag=false;
			   try {
				  String x= newdriver.findElement(By.tagName("table")).getTagName();
				  
				  if(x.equalsIgnoreCase("table"))
				  {
					 bflag=true;
				  }
			   }catch (Exception e) {
				   bflag=false;
				   ExceptionHandle.HandleException(e, "User is not in list table");
			   }
			return bflag;
			   
				
				 }
			@Then("^I enter \"(.*)\" FirstName \"(.*)\" Data from sheet \"(.*)\"$") 
			public void EnterUserName(String sStatus,String sUsername,String sSheetName) throws InterruptedException{
				try {
					XSSFSheet ExcelWSheet =ExcelUtils.getSheetObj(ActionsClass.TestDataPath,sSheetName);
					sUsername = ExcelUtils.getCellValueOnColumName(ExcelWSheet, sUsername, 1);
					newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					ActionsClass.typeInTextBox(RegisterUserObjects.FirstName_Txtbox,sUsername,"Username");
					Thread.sleep(500);
				}catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to enter username");
				}
			}
			
			@Then("^I enter \"(.*)\" LastName \"(.*)\" Data from sheet \"(.*)\"$") 
			public void EnterUserLastName(String sStatus,String sLastname,String sSheetName) throws InterruptedException{
				try {
					XSSFSheet ExcelWSheet =ExcelUtils.getSheetObj(ActionsClass.TestDataPath,sSheetName);
					sLastname = ExcelUtils.getCellValueOnColumName(ExcelWSheet, sLastname, 1);
					newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					ActionsClass.typeInTextBox(RegisterUserObjects.LastName_Txtbox,sLastname,"Lastname");
					Thread.sleep(500);
				}catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to enter LastName");
				}
			}
			@Then("^I enter \"(.*)\" Password \"(.*)\" Data from sheet \"(.*)\"$") 
			public void PasswordData(String sStatus,String sPassword,String sSheetName) throws InterruptedException{
				try {
					XSSFSheet ExcelWSheet =ExcelUtils.getSheetObj(ActionsClass.TestDataPath,sSheetName);
					sPassword = ExcelUtils.getCellValueOnColumName(ExcelWSheet, sPassword, 1);
					newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					ActionsClass.typeInTextBox(RegisterUserObjects.Password_Txtbox,sPassword,"Password");
					Thread.sleep(500);
				}catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to enter Password");
				}
			}
			@Then("^I enter \"(.*)\" Email \"(.*)\" Data from sheet \"(.*)\"$") 
			public void EnterEmailID(String sStatus,String sEmail,String sSheetName) throws InterruptedException{
				try {
					XSSFSheet ExcelWSheet =ExcelUtils.getSheetObj(ActionsClass.TestDataPath,sSheetName);
					sEmail = ExcelUtils.getCellValueOnColumName(ExcelWSheet, sEmail, 1);
					newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					ActionsClass.typeInTextBox(RegisterUserObjects.Email_Txtbox,sEmail,"Username");
					Thread.sleep(500);
				}catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to enter Email");
				}
			}
			@Then("^I enter \"(.*)\" PhoneNumber \"(.*)\" Data from sheet \"(.*)\"$") 
			public void EnterCellNumber(String sStatus,String sPhNumb,String sSheetName) throws InterruptedException{
				try {
					XSSFSheet ExcelWSheet =ExcelUtils.getSheetObj(ActionsClass.TestDataPath,sSheetName);
					sPhNumb = ExcelUtils.getCellValueOnColumName(ExcelWSheet, sPhNumb, 1);
					newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					ActionsClass.typeInTextBox(RegisterUserObjects.Phone_Txtbox,sPhNumb,"Username");
					Thread.sleep(500);
				}catch (Exception e) {

					ExceptionHandle.HandleException(e, "Failed to enter Phonenumber");
				}
			}
			
			
			@Then("^I enter \"(.*)\" Data from properties")
			
			public void user1property(String Userdata) {
				try {
					if(Userdata.equalsIgnoreCase("User1FirstName")||Userdata.equalsIgnoreCase("User2FirstName")) {
					String PropertiesData=Utils.getProperty(Userdata);
					ActionsClass.typeInTextBox(RegisterUserObjects.FirstName_Txtbox,PropertiesData,"username");
					}else if(Userdata.equalsIgnoreCase("User1LastName")||Userdata.equalsIgnoreCase("User2LastName")) {
					String PropertiesData=Utils.getProperty(Userdata);
					ActionsClass.typeInTextBox(RegisterUserObjects.LastName_Txtbox,PropertiesData,"LastName");
					}else if(Userdata.equalsIgnoreCase("User1Password")||Userdata.equalsIgnoreCase("User2Password")) {
					String PropertiesData=Utils.getProperty(Userdata);
					ActionsClass.typeInTextBox(RegisterUserObjects.Password_Txtbox,PropertiesData,"Password");
					}else if(Userdata.equalsIgnoreCase("User1Email")||Userdata.equalsIgnoreCase("User2Email")) {
					String PropertiesData=Utils.getProperty(Userdata);
					ActionsClass.typeInTextBox(RegisterUserObjects.Email_Txtbox,PropertiesData,"Email");
					}else if(Userdata.equalsIgnoreCase("User1Cell")||Userdata.equalsIgnoreCase("User1Cell")) {
					String PropertiesData=Utils.getProperty(Userdata);
					ActionsClass.typeInTextBox(RegisterUserObjects.Phone_Txtbox,PropertiesData,"CellNumber");
				}}
				catch (Exception e){
					ExceptionHandle.HandleException(e, "Fail to fetch data from :"+Userdata);
					
				}
			}
				
			
		
	}
		 



	 






