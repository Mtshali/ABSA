package seleniumgluecode;



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import accelerators.Base;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import utility.ExceptionHandle;
import utility.Utils;

public class WebAPIMethods {
	static WebDriver newdriver = Base.driver;
	public static String response ="";
	public static String sToken ="";
	//public static String ABSAsToken="";
	public static int responseCode;
	
	@Given("^Launch Browser for token$")
	public static void launchTheBrowser() {
		try { 
			Base.sBrowserName= Utils.getProperty("browserName");
			System.out.println("BrowserType: "+Base.sBrowserName);
			newdriver=Base.OpenBrowser(Base.sBrowserName);
			newdriver=Base.driver;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
		@Then("^Call the webservice method \"(.*)\"$")
	public static void callGetMethod(String sURL) throws Throwable{
		try {  
			    BufferedReader reader = null;
			    URL url = new URL(sURL);
			    HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			    connection.setRequestProperty("Authorization", "Bearer " + sToken);
			    connection.setDoOutput(true);
			    connection.setRequestMethod("GET");
			    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			   
			    String line = null;
			    StringWriter out = new StringWriter(connection.getContentLength() > 0 ? connection.getContentLength() : 2048);
			    while ((line = reader.readLine()) != null) {
			        out.append(line);
			    }
			    responseCode = connection.getResponseCode();
			    System.out.println(responseCode);
			    response = out.toString();
			    System.out.println(response); 
			    
		    }catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to get the request "+sURL);

		   }
	       }

		 @And ("^Verify the retriver bread is within the list$") 
		 public static void verifyRetrieverBread(){
			 try {
 			 Assert.assertSame(true, response.contains("retriever"));
			     {
			      utility.Log.info("Retriver bread is within the list");
			      System.out.println("Retriver bread is within the list");
			    }
			     }
			 catch (Exception e) {
             ExceptionHandle.HandleException(e, "fail to verify Retriever bread");
			 Assert.fail("Failed to verify Retriver bread");
			 System.out.println("fail to verify Retriver bread");
				}}
		 
		@And ("^Verify the response code$")
		public static void verifyResponseCode() throws Throwable{
			try {
				if(responseCode==200) {
					System.out.println("Response code is:"+responseCode);
					utility.Log.info("Response code is:"+responseCode);
                 }else {
                	Assert.fail("Response code is not 200"); 
                 }
			}catch(Exception e) {
				Assert.fail("Response code is not 200");
			}
		}
	   

	}
	
	
		
	



