package utility;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import accelerators.Base;

public class Utils extends Base{
	

	private static WebDriver driver = null;
	public static String FILE_NAME = System.getProperty("user.dir")+"//ProjectData//config.properties";
	public static Properties properties=null;

	public static WebDriver openBrowser(int iTestCaseRow) throws Exception{

		String sBrowserName;
		try {
			//sBrowserName = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Browser);
			sBrowserName="Chrome";
			if(sBrowserName.equals("Mozilla")){
				driver = new FirefoxDriver();           
				Log.info("New driver instantiated");	
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Log.info("Implicit wait applied on the driver for 10 seconds");
				driver.get(Constant.Application_URL);
				Log.info("Web application launched successfully");
			}
			if(sBrowserName.equals("Chrome")){
				System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
				driver = new ChromeDriver();
				Log.info("New driver instantiated");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Log.info("Implicit wait applied on the driver for 10 seconds");
				driver.get(Constant.Application_URL);
				Log.info("Web application launched successfully");
			}
		}catch (Exception e){

			Log.error("Class Utils | Method OpenBrowser | Exception desc : "+e.getMessage());
		}

		return driver;
	}

	static {
		File f = new File(FILE_NAME);
		properties = new Properties();
		FileInputStream in;
		try {
			in = new FileInputStream(f);
			properties.load(in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getProperty(String strKey) {
		String strValue = null;
		try{
			File f = new File(FILE_NAME);
			if(f.exists()){
				strValue=properties.getProperty(strKey);
			}
			else
				System.out.println("File not found!");
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return strValue;
	}

	public static String getTestCaseName(String sTestCase)throws Exception{
		String value = sTestCase;
		try{
			int posi = value.indexOf("@");
			value = value.substring(0, posi);
			posi = value.lastIndexOf(".");    
			value = value.substring(posi + 1);
			return value;
		}catch (Exception e){
			Log.error("Class Utils | Method getTestCaseName | Exception desc : "+e.getMessage());
			throw (e);
		}
	}

	

    public static void takeScreenshot(WebDriver driver, String sTestCaseName,String path) throws Exception{
        try{
               File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
               FileUtils.copyFile(scrFile, new File(path + sTestCaseName +".jpg"));
        } catch (Exception e){
               Log.error("Class Utils | Method takeScreenshot | Exception occured while capturing ScreenShot : "+e.getMessage());
               throw new Exception();
        }
 }


	public static void createNewFile(String sFilePath) throws IOException {
		File file = new File(sFilePath);
		file.createNewFile();
	}

	public static void copyFile(String sCopyFromFilePath,String sCopyToPath) throws Exception{
		try {
			FileInputStream Fread =new FileInputStream(sCopyFromFilePath); 
			FileOutputStream Fwrite=new FileOutputStream(sCopyToPath) ; 
			int c; 
			while((c=Fread.read())!=-1) 
				Fwrite.write((char)c); 

			Fread.close();
			Fwrite.close(); 
			System.out.println("File is Copied");          
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void writeDataIntoFile(String sFilepath,String sContent) throws IOException{
		BufferedWriter  bw=null;
		FileWriter  fw =null;
		try {
			fw = new FileWriter(sFilepath);
			bw = new BufferedWriter(fw);
			bw.write(sContent);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			bw.close();
			fw.close();
		}
	}
	
	public static String readDataFromFile(String sFilepath) throws IOException{
		 BufferedReader br = new BufferedReader(new FileReader(sFilepath));
		    try {
		        StringBuilder sb = new StringBuilder();
		        String line = br.readLine();

		        while (line != null) {
		            sb.append(line);
		            sb.append("\n");
		            line = br.readLine();
		        }
		        return sb.toString();
		    } finally {
		        br.close();
		    }
	}
	public static void updateDataInFile(String sFilePath,String sKey,String sValue) throws IOException{
		try {
			if(!sKey.contains("@")) {
				sKey="@"+sKey;
			}
			Path path = Paths.get(sFilePath);
			String fileContent = new String(Files.readAllBytes(path));
			Files.write(path, fileContent.getBytes());			
			if(fileContent.contains(sKey)) {
				fileContent = fileContent.replaceAll(sKey, sValue);	
			}
			Files.write(path, fileContent.getBytes());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
			
	}

