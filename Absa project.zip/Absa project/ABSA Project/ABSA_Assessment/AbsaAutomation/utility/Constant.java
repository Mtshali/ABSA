package utility;

public class Constant {
	

	public static final String Application_URL ="http://www.way2automation.com/angularjs-protractor/webtables/";
	public static final String Path_SeleniumDriver = "C://Programs//eclipse//Lib//seleniumdrivers//";	
	public static final String Path_ScreenShot = "C://Workspace//ABSA_Assessment//Screenshots//";
	public static final String Path_TestData="C://Workspace//LexisNexisCucumber//TestData//";
	public static final String File_TestData="LS_700_Access_and_Security_Login_with_correct_credentials.xlsx";
}
