package utility;

import static org.testng.Assert.fail;
import accelerators.ActionsClass;

public class ExceptionHandle {
    
	//Function to handle exceptions
    public static void HandleException(Exception e, String sError) {
           try {
//                  System.out.println(sError);
//                  System.out.println(e.getStackTrace().toString()); 
                  utility.Log.info(e.getStackTrace().toString());
                  ActionsClass.GetScreenShot();
                  fail(sError);
                  } catch (Exception ex) {
                        System.out.println(ex.getStackTrace().toString()); 
                  }
    }

}
